<?php

$connect = mysqli_connect('localhost','root','root','redbird');
if (!$connect)
{
    die('Ошибка конекта к бд');
}
 ?>