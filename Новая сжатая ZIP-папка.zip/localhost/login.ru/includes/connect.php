<?php

$connect = mysqli_connect('localhost','root','','test');
if (!$connect)
{
    die('Ошибка конекта к бд');
}
 ?>