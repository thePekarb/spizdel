<?php
session_start();
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title> Авторизации </title>
    <link rel="stylesheet" href="assets/css/styles.css">
</head>
<body>
    <!-- здесь пошла форма профиля-->

    <form>
    <h2><?= $_SESSION['users']['full_name'] ?></h2>
    <h2><?= $_SESSION['users']['email'] ?></h2>
    </form>
    
</body>
</html>