<?php
$conn = mysqli_connect("localhost", "root", "root", "mynews");
if (!$conn) {
    die("Ошибка: " . mysqli_connect_error());
}
$sql = "SELECT id, title FROM `new` ";
$result = mysqli_query($conn, $sql);
if (isset($_GET["id"])) {
    $id = $_GET["id"];
}
$newId = mysqli_real_escape_string($conn, $_GET["id"]);
$newFullSelection = "SELECT * FROM `new` WHERE id = '$newId'";
$newResult = mysqli_query($conn, $newFullSelection);
?>
<!DOCTYPE html>
<html lang="ru">


<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="styles/style1.css">
    <title>Новости</title>
</head>
<style>

        body { background-image: url(img/bg.jpg);}
        </style>
<div class="main">
    <header class="head">
        <div class="left">
            <div class="logo">
                <img src="img/logo.jpg" class="respons" alt="">
                <span class="header_info">Новости Волгограда<br> На связи 24/7</span>

            </div>
    <div class="cont">
   <form action = "" method="POST" enctype="multipart/form-data" style="font-size: 20px; color:white">
   <p><label for="" >Введите заголовок Новости</label></p>
   <p><input type="text" name="name" required></p>
   <p><label for="" >Введите изображение для Новости</label></p>
   <p><input type="file" name="image" required></p>
   <p><label for="" >Введите текст Новости</label></p>
   <p><textarea name="text" cols="30" rows="10" ></textarea></p>
   <p><label for="" >Введите текст Новости</label></p>
   <p><textarea name="full" cols="50" rows="10" ></textarea></p>
                    <p><input type="submit" value="Сохранить"></p>
                    </form>
                    <?php
                     echo "<h3><a href='index2.php?id=" . $newRow['id'] ."'> Назад </a></h3>";
                    ?>
            <?php
            if(isset($_POST["name"]) && isset($_POST["text"]) && isset($_POST["full"]) && !empty($_FILES['image']['tmp_name'])){
                $name = $_POST["name"];
                $image = addslashes(file_get_contents($_FILES['image']['tmp_name']));
                $text = $_POST["text"];
                $full = $_POST["full"];
                $id = $_GET["id"];
                $newred = "INSERT INTO `new`( name, image, text, full) VALUES ('$name','$image','$text','$full')";
                if ($conn->query($newred)) {
                    echo "<script>alert(\"Новость отредактированна\");</script>";
                } else {
                    echo "Ошибка: " . $conn->error;
                }
            }
            ?>                    
    </div>
        </div>
        <footer>
            <div>News© 2022</div>
        </footer>
</body>
</html>