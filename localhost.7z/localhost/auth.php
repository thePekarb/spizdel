<?php

session_start();

$conn = mysqli_connect("localhost", "root", "root", "mynews");

if (!$conn) {
    die("Ошибка: " . mysqli_connect_error());
}
?>
<!DOCTYPE html>
<html lang="ru">


<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="styles/style1.css">
    <title>Авторизация</title>
</head>
 <style>

        body { background-image: url(img/bgc.jpg);}
        </style>
<div class="main">
    <header class="head">
        <div class="left">
            <div class="logo">
                <img src="img/logo.jpg" class="respons" alt="">
                <span class="header_info">Новости Волгограда<br> На связи 24/7</span>
            </div>

        </div>

    </header>


</div>
</div>
<div id="container" >
    <header class="head">
        <div class="center">
            <link rel="stylesheet" href="styles/styles.css">
            <div id="wrapper">
                <div id="login" class="animate form">
                    <form action="index1.php" method="post">
                        <h3> <div class="center"> Авторизация</h3>
                        <p>
                            <label for="login" class="login" data-icon="u" > Логин </label>
                            <input id="login" name="login" required="required" type="text"/>
                        </p>
                        <p>
                            <label for="password" class="password" data-icon="p"> Пароль </label>
                            <input id="password" name="password" required="required" type="password"/>
                        </p>
                        <p class="login button">
                            <input type="submit" value="Войти" />
                        </p>
                    </form>
                    <?php
                    if(isset($_POST["login"]) && isset($_POST["password"]))
                    {
                        $login = $_POST["login"];
                        $auth = "SELECT * FROM `admin` WHERE login='$login'";
                        $authResult = mysqli_query($conn,$auth);
                        $authAssoc = mysqli_fetch_assoc($authResult);
                        if(!empty($authAssoc)){
                            $hash = $authAssoc['password'];
                            if(password_verify($_POST['password'], $hash)){
                                $adminid = $authAssoc['id'];
                                $_SESSION["adminid"] = $adminid;
                                echo "Авторизация успешна";
                            }

                            else {
                                echo "Неверный пароль";
                            }
                        }
                        else
                        {
                            echo "Неверный логин";
                        }
                    }

                    ?>
                </div>
                </div>
                <footer>
                    <div>News© 2022</div>
                </footer>
</body>
</html>