<?php
session_start();
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title> Авторизации </title>
    <link rel="stylesheet" href="assets/css/main.css">
</head>
<body>
    <!-- здесь пошла форма регистрации-->

    <form action="includes/signup.php" method="post">
        <label> ФИО </label>
        <input type="text" name = "full_name" placeholder="Введите свое полное имя">
        <label> email </label>
        <input type="email" name = "email"  placeholder="Введите свой email">
        <label> Логин </label>
        <input type="text" name = "login" placeholder="Введите логин">
        <label> Пароль </label>
        <input type="password" name = "password" placeholder="Введите пароль">
        <label> Подвердите пароль </label>
        <input type="password" name = "password_confirm" placeholder="Введите пароль">
        <button type="sudmit">Зарегистироваться</button>
        <p>
            У вас уже есть аккаунт ? - <a href="index.php"> Авторизируйтесь</a>!
        </p>

        <?php 
        if ($_SESSION['message']){
            echo '<p  class = "message"> '. $_SESSION['message'] .' </p>';
        }
             unset($_SESSION['message']);
        ?>


    </form>
</body>
</html>