<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/styles.css">
    <title>RedBird</title>
</head>
<body>
<div class="header">
    <img src="css/img/fone.png" alt="" width="200px" >
</div>

<form action="Up.php" method="post">
        <label> ФИО </label>
        <input type="text" name = "full_name" placeholder="Введите  полное имя">
        <label> email </label>
        <input type="email" name = "email"  placeholder="Введите  email">
        <label> Логин </label>
        <input type="text" name = "login" placeholder="Введите логин">
        <label> Пароль </label>
        <input type="password" name = "password" placeholder="Введите пароль">
        <label> Подвердите пароль </label>
        <input type="password" name = "password_confirm" placeholder="Введите пароль ещё раз">
        <button type="sudmit">Зарегистироваться</button>
        <p>
            Вы уже зарегистрированны  ? - <a href="index.php"> Авторизируйтесь</a>!
        </p>

        <?php 
        if ($_SESSION['message']){
            echo '<p  class = "message"> '. $_SESSION['message'] .' </p>';
        }
             unset($_SESSION['message']);
        ?>


    </form>

    
</form>
</body>
</html>