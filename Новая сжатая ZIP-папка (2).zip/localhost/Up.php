<?php
    session_start();
    require_once 'connect.php';
    
    $full_name = $_POST['full_name'];
    $login = $_POST['login'];
    $email = $_POST['email'];
    $password = $_POST['password'];
  

    if($password === $password_confirm)
    {
        //con..  
        $password = md5($password); //добавление хешера
        mysqli_query($connect,"INSERT INTO `users` (`id`, `full_name`, `email`, `login`, `password`) VALUES (NULL, '$full_name', '$email', '$login', '$password')");
        $_SESSION['message'] = 'Регистрация прошла успешно';
        header('Location:../index.php');
    }
    else {
        $_SESSION['message'] = 'Пароли не совпадают';
        header('Location:../registrarion.php');
    }
?>