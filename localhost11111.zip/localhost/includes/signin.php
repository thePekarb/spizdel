<?php
session_start();
if(!empty($_POST['submitauth'])){
    header('Refresh: 0');

}
if (isset($_SESSION['userid'])) {
    header('Location: ../index.php');
}
$connect = mysqli_connect('localhost','root','root','jaloba');

if (isset($_POST["login"]) && isset($_POST["password"])) {
    $login = $_POST["login"];
    $auth = "SELECT * FROM `users` WHERE login='$login'";
    $authResult = mysqli_query($connect, $auth);
    $authAssoc = mysqli_fetch_assoc($authResult);
    if (!empty($authAssoc)) {
        $hash = $authAssoc['password'];
        if (password_verify($_POST['password'], $hash)) {
            $userid = $authAssoc['id'];
            $userlogin = $authAssoc['login'];
            $_SESSION["login"] = $userlogin;
            $_SESSION["userid"] = $userid;

        } else {
            echo "<p>Пароль неверный</p>";
        }
    } else {
        echo "<p>Пользователя с таким логином не существует</p>";
    }
}



?>