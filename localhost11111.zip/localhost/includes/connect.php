<?php

$connect = mysqli_connect('localhost','root','root','jaloba');
if (!$connect)
{
    die('Ошибка конекта к бд');
}
 session_start();
 ?>