<?php
session_start();
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title> Авторизации </title>
    <link rel="stylesheet" href="assets/css/styles.css">
</head>
<body>
<!-- здесь пошла форма регистрации-->

<form action="includes/signup.php" method="post" enctype="multipart/form-data">


    <input type="text" name = "login" placeholder="Введите логин">

    <input type="password" name = "password" placeholder="Введите пароль">

    <button type="submit" name="submitreg">Зарегистироваться</button>
    <p>
        У вас уже есть аккаунт ? - <a href="indexvxod.php"> Авторизируйтесь</a>!
    </p>

    <?php
    if ($_SESSION['message']){
        echo '<p  class = "message"> '. $_SESSION['message'] .' </p>';
    }
    unset($_SESSION['message']);
    ?>


</form>
</body>
</html>
