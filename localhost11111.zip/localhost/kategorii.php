<?php
session_start();
$conn = mysqli_connect("localhost", "root", "root", "redbird");
$userid = $_SESSION['userid'];
$userInfoSelect = "SELECT * FROM `stranica` WHERE userId = '$userid'";
$userInfoSelectResult = mysqli_query($conn, $userInfoSelect);
$userInfoFetchAssoc = mysqli_fetch_assoc($userInfoSelectResult);
if (isset($_POST['redact']) && !empty($userInfoFetchAssoc)) {
} else if (empty($userInfoFetchAssoc) && isset($_POST['redact'])) {
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Адаптивная вёрстка сайта</title>
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Open+Sans:400,400italic,600,600italic,700,700italic|Playfair+Display:400,700&subset=latin,cyrillic">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.4.0/css/font-awesome.css">
    <link rel="stylesheet" type="text/css" href="style.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.2/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/prefixfree/1.0.7/prefixfree.min.js"></script>

</head>
<body>
<header>
    <nav class="container">
        <a class="logo" href="">
            <span>J</span>
            <span>A</span>
            <span>L</span>
            <span>O</span>
            <span>B</span>
            <span>A</span>
            <span>.</span>
            <span>R</span>
            <span>U</span>
        </a>
        <div class="nav-toggle"><span></span></div>

        <ul id="menu">
            <li>
                
            <?php
            $conn = new mysqli("localhost", "root", "root", "jaloba");
            if($conn->connect_error){
                die("Ошибка: " . $conn->connect_error);
            }
            $sql = "SELECT id, kategorii,jaloba,reg,login,vixod FROM menu";
            if($result = $conn->query($sql)){

                foreach($result as $row){
                    echo "<tr>";
                    echo "<td>" . $row["kategorii"] . "</td><p></p>";
                    echo "<td>" . $row["jaloba"] . "</td><p></p>";
                    echo "<td>" . $row["reg"] . "</td><p></p>";
                    echo "<td>" . $row["login"] . "</td><p></p>";
                    echo "<td>" . $row["vixod"] . "</td><p></p>";
                    // echo "<td><a href='user.php?id=" . $row["id"] . "'>Подробнее</a></td>";//
                    echo "</tr>";
                }
                $result->free();
            } else{
                echo "Ошибка: " . $conn->error;
            }
            $conn->close();

            echo "</table>";
            ?>
            </li>
        </ul>
    </nav>
</header>

<div class="container">
    <div class="posts-list">
        <article id="post-1" class="post">
            <div class="post-image">


            </div>
            <div class="post-content">
                <div class="category"><h2><a href="">Выберите категорию</a></h2></div>
                <p></p>
                <div class="category-menu">
                    <?php
                    $conn = new mysqli("localhost", "root", "root", "jaloba");
                    if($conn->connect_error){
                        die("Ошибка: " . $conn->connect_error);
                    }
                    $sql = "SELECT id, president,administr,dolj FROM kategorii";
                    if($result = $conn->query($sql)){

                        foreach($result as $row){
                            echo "<tr>";
                            echo "<td>" . $row["president"] . "</td><p></p>";
                            echo "<td>" . $row["administr"] . "</td><p></p>";
                            echo "<td>" . $row["dolj"] . "</td><p></p>";

                            // echo "<td><a href='user.php?id=" . $row["id"] . "'>Подробнее</a></td>";//
                            echo "</tr>";
                        }
                        $result->free();
                    } else{
                        echo "Ошибка: " . $conn->error;
                    }
                    $conn->close();

                    echo "</table>";
                    ?>
                </div>
                <h3 class="post-title">О нас</h3>
                <p>Мы одни из крупнейших в России специализированных магазинов спортивного питания с 59 офлайн магазинами и интернет-магазином с более 3 тысяч товаров в наличии.</p>
                <!--<div class="post-footer">
                    <a class="more-link" href="">Продолжить чтение</a>
                    <div class="post-social">
                        <a href="" target="_blank"><i class="fa fa-facebook"></i></a>
                        <a href="" target="_blank"><i class="fa fa-twitter"></i></a>
                        <a href="" target="_blank"><i class="fa fa-pinterest"></i></a>
                    </div>
                </div>-->
            </div>

        </article>
        <article id="post-2" class="post">
            ...
        </article>
    </div> <!-- конец div class="posts-list"-->

</div> <!-- конец div class="container"-->
<footer>
    <div class="container">
        <div class="footer-col"><span>sportесть © 2022</span></div>
        <div class="footer-col">
            <div class="social-bar-wrap">
                <a title="Facebook" href="" target="_blank"><i class="fa fa-facebook"></i></a>
                <a title="Twitter" href="" target="_blank"><i class="fa fa-twitter"></i></a>
                <a title="Pinterest" href="" target="_blank"><i class="fa fa-pinterest"></i></a>
                <a title="Instagram" href="" target="_blank"><i class="fa fa-instagram"></i></a>
            </div>
        </div>
        <div class="footer-col">
            <a href="mailto:admin@yoursite.ru">Написать письмо</a>
        </div>
    </div>
</footer>


</body>
</html>