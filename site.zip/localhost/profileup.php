<?php
session_start();

$connect=mysqli_connect("localhost", "root", "root", "redbird");

if (!$connect) {
    die("Ошибка: " . mysqli_connect_error());
}


?>
<!DOCTYPE>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>RedBird</title>

    <link href="templatemo_style.css" rel="stylesheet" type="text/css" />

    <link rel="stylesheet" href="assets/css/profile.css" type="text/css" media="screen" charset="utf-8" />



</head>
<body>

<div id='flex-container'>

    <div id="head">
        <div id="templatemo_header">
            <a href="#index2" target="_parent"><img src="img/fone.png" alt="Mini Social" width="200px" height="100px" /></a>
            <div class="text-header">REDBIRD</div>
        </div>

    </div>

    <div class="content">
        <div class="menu-top">
            <ul id="social_box">
                <li><a href=""><img src="images/pleer.png" alt="playyer" /></a></li>
                <li><a href=""><img src="images/uvedomlenie.png" alt="sms" /></a></li>
                <li><a href=""><img src="images/uvedomlenie.png" alt="gallery" /></a></li>
                <input type="text"></input>
                <li><button><img src="images/search.png" alt="linkin" /></button></li>

            </ul>
        </div>
        <div class="menu-down">
            <ul class="navigation">
                <li><a href="index3.php">Главная страница<span class="ui_icon home"></span></a></li>
                <li><a href="#aboutus">Сообщения<span class="ui_icon aboutus"></span></a></li>
                <li><a href="#services">Виджеты<span class="ui_icon services"></span></a></li>
                <li><a href="#gallery">Галлерея<span class="ui_icon gallery"></span></a></li>
                <li><a href="#contactus">поддержка<span class="ui_icon contactus"></span></a></li>
            </ul>
            <div id="text">

                <div class="cont-phone">

                        <div class="header-profile">
                            <form action="includes/signup2.php" method="post" enctype="multipart/form-data">
                                <label> ФИО </label>
                                <input type="text" name = "full_name" placeholder="Введите свое полное имя">
                                <label> email </label>
                                <input type="email" name = "email"  placeholder="Введите свой email">
                                <label> Выберите изображение </label>
                                <input type="file" name="avatar">
                                <label> Город </label>
                                <input type="text" name = "gorod" placeholder="Введите название города">
                                <label> О себе </label>
                                <input type="text" name = "o_sebe" placeholder="Введите информацию о себе">
                                <button type="submit" value="Submit" name="edit">Редактировать</button>


                                <?php
                                if ($_SESSION['message']){
                                    echo '<p  class = "message"> '. $_SESSION['message'] .' </p>';
                                }
                                unset($_SESSION['message']);
                                ?>


                            </form>



                        </div>





                </div>
            </div>
        </div>


        <div id="footer"> @Copyright2022

        </div>




    </div>

</body>
</html>