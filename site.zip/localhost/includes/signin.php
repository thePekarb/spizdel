<?php
    session_start();
$id = $_SESSION['id'];

    require_once 'connect.php';

    $login = $_POST['login'];
    $password = md5($_POST['password']);


    $check_user = mysqli_query($connect, "SELECT * FROM `users` WHERE `login` = '$login' AND `password` = '$password'");//проверка условий,если совпадает хотя бы одно, то авторизируемся
    if (mysqli_num_rows($check_user) > 0)//подсчёт схожих строк с запросом
    {
        $user = mysqli_fetch_assoc($check_user);//преобразование ключей в нормальный массив
        $check_stranica = mysqli_query($connect,"INSERT INTO `stranica` (`id`, `user_id`) VALUES (NULL,'$user_id' )");





        $_SESSION['user'] = [
            "id"=>$user['id'],
            "full_name"=> $user['full_name'],   
            "email"=> $user['email'],
             "avatar"=>$user['avatar']
            
        ];



         header('Location:../index3.php');
       
    }
    else
    {
        $_SESSION['message'] = 'Неверный логин или пароль';
        header('Location:../index.php');
    }
?>