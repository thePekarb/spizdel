<?php
    session_start();

    require_once 'connect.php';

    $stanica_id = $_POST['id'];
    $full_name = $_POST['full_name'];
    $gorod = $_POST['gorod'];
    $email = $_POST['email'];
    $o_sebe = $_POST['o_sebe'];

    

    if(isset($_POST['edit']))//сравнение паролей
    {
        $_FILES['avatar'];
        $path = 'uploads/' .time(). $_FILES['avatar']['name'];//загрузка фото+ path- переменная пути загрузки фото
        if(! move_uploaded_file($_FILES['avatar']['tmp_name'],'../' . $path))
        {
             $_SESSION['message'] = 'Фото не грузит';
        header('Location:../reg.php');
        }


        mysqli_query($connect,"UPDATE `stranica` SET `id`=NULL,`id_user`=NULL ,`full_name`='$full_name',`email`='$email',`avatar`='$path',`gorod`='$gorod',`o_sebe`='$o_sebe' WHERE id=' $stanica_id'");//тут мы отправляем данные на сервер
        $_SESSION['message'] = 'Регистрация прошла успешно';
        header('Location:../index3.php');
    }
    else {
        $_SESSION['message'] = 'Пароли не совпадают';
        header('Location:../reg.php');
    }
?>