<?php
    session_start();
    require_once 'connect.php';


    $user_id = $_POST['user_id'];
    $full_name = $_POST['full_name'];
    $login = $_POST['login'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $password_confirm = $_POST['password_confirm'];
    

    if($password === $password_confirm)//сравнение паролей
    {
        $_FILES['avatar'];
        $path = 'uploads/' .time(). $_FILES['avatar']['name'];//загрузка фото+ path- переменная пути загрузки фото
        if(! move_uploaded_file($_FILES['avatar']['tmp_name'],'../' . $path))
        {
             $_SESSION['message'] = 'Фото не грузит';
        header('Location:../reg.php');
        }
        $password = md5($password); //добавление хешера

        mysqli_query($connect,"INSERT INTO `users` (`id`, `full_name`, `login`, `email`, `password`, `avatar`) VALUES (NULL, '$full_name', '$login', '$email', '$password', '$path')");

        //тут мы отправляем данные на сервер
        $_SESSION['message'] = 'Регистрация прошла успешно';
        header('Location:../index.php');
    }
    else {
        $_SESSION['message'] = 'Пароли не совпадают';
        header('Location:../reg.php');
    }
?>