<?php
    session_start();
    require_once 'connect.php';


    $user_id = $_SESSION['id'];
    $full_name = $_POST['full_name'];
    $gorod = $_POST['gorod'];
    $email = $_POST['email'];
    $o_sebe = $_POST['o_sebe'];

    

    if(isset($_POST['edit']))//сравнение паролей
    {
        $_FILES['avatar'];
        $path = 'uploads/' .time(). $_FILES['avatar']['name'];//загрузка фото+ path- переменная пути загрузки фото
        if(! move_uploaded_file($_FILES['avatar']['tmp_name'],'../' . $path))
        {
             $_SESSION['message'] = 'Фото не грузит';
        header('Location:../reg.php');
        }


        mysqli_query($connect,"INSERT INTO `stranica` (`id`, `user_id`, `full_name`, `email`, `avatar`, `gorod`, `o_sebe`) VALUES ( NULL,'$user_id', '$full_name', '$email', '$path', '$gorod', '$o_sebe')");//тут мы отправляем данные на сервер
        $_SESSION['message'] = 'Данные сохранены';
        header('Location:../index3.php');
    }
    else {
        $_SESSION['message'] = 'Пароли не совпадают';
        header('Location:../reg.php');
    }
?>