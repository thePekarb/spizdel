<?php
session_start();

$conn=mysqli_connect("localhost", "root", "root", "redbird");

if (!$conn) {
    die("Ошибка: " . mysqli_connect_error());
  }


?>
<!DOCTYPE>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>RedBird</title>

<link href="templatemo_style.css" rel="stylesheet" type="text/css" />

<link rel="stylesheet" href="assets/css/coda-slider.css" type="text/css" media="screen" charset="utf-8" />



</head>
<body>

<div id='flex-container'>

  <div id="head">
  <div id="templatemo_header">
        	<a href="#index2" target="_parent"><img src="img/fone.png" alt="Mini Social" width="200px" height="100px" /></a>
            <div class="text-header">REDBIRD</div>
        </div>

  </div>

        <div class="content">
            <div class="menu-top">
        <ul id="social_box">
            <li><a href=""><img src="images/pleer.png" alt="playyer" /></a></li>
            <li><a href=""><img src="images/uvedomlenie.png" alt="sms" /></a></li>
            <li><a href=""><img src="images/uvedomlenie.png" alt="gallery" /></a></li>
            <input type="text"></input>
            <li><button><img src="images/search.png" alt="linkin" /></button></li>
                  
            </ul>
</div>
<div class="menu-down">
            <ul class="navigation">
            <li><a href="index3.php">Главная страница<span class="ui_icon home"></span></a></li>
            <li><a href="#aboutus">Сообщения<span class="ui_icon aboutus"></span></a></li>
            <li><a href="#services">Друзья<span class="ui_icon services"></span></a></li>
            <li><a href="#gallery">Галлерея<span class="ui_icon gallery"></span></a></li>
            <li><a href="#contactus">поддержка<span class="ui_icon contactus"></span></a></li>
             </ul>
            <div id="text">
            
                <div class="cont-phone">
                   <form>
                       <div class="header-profile">
                           <div class="photo-profile">
                               <img src="<?= $_SESSION['user']['avatar'] ?>" width="200" alt="">



                           </div>

                           <div class="text-profile">
                               <div class="nameh">
                                   <h1><?= $_SESSION['user']['full_name'] ?></h1>
                               </div>

                               <div class="about-profile">
                                  <h3> <label>Email:</label></h3>
                                   <h1><?= $_SESSION['user']['email'] ?></h1>
                                   <br><a href="profile.php">Заполнить  профиль</a>
                                   <br><a href="profile.php">редактировать  профиль</a>
                               </div>


                           </div>



                       </div>




                     </form>
                        <div class="information-profile">
                            <h1><?= $_SESSION['stranica']['full_name'] ?></h1>

                        </div>
                            <div class="right-menu">


                            </div>
                </div>
            </div>
</div>


                <div id="footer"> @Copyright2022

                </div>




</div>

</body>
</html>