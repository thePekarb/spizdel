<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Адаптивная вёрстка сайта</title>
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Open+Sans:400,400italic,600,600italic,700,700italic|Playfair+Display:400,700&subset=latin,cyrillic">
    <link rel="stylesheet" type="text/css" href="style.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.2/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/prefixfree/1.0.7/prefixfree.min.js"></script>
</head>

<body>
    <header>
        <nav class="container nav__container">
            <a class="logo" href="">
                <p>Купить билеты.ру</p>
            </a>
            <!-- <div class="nav-toggle"><span></span></div> -->
            <form action="" method="get" id="searchform">
                <input type="text" placeholder="Искать на сайте...">
                <button type="submit"><i class="fa fa-search"></i></button>
            </form>
            <ul class="menu">
                <li><a href="buyticket.php">Купить билеты</a></li>
                <li><a href="">Контакты</a></li>
                <li><a href="">Об авторе</a></li>
                <li><a href="log.php">вход</a></li>
            </ul>
        </nav>
    </header>
    <div class="container">
        <div class="posts-list">
            <article id="post-1" class="post">
                <div class="post-image"><a href=""><img src="image/IMG_0409-17-05-18-04-55.jpg"></a></div>
                <div class="post-content">
                    <div class="category"><a href="">Дизайн</a></div>
                    <h2 class="post-title">Весна</h2>
                    <p>Очень богат русский язык словами, относящимися к временам года и к природным явлениям, с ними связанным.</p>
                    <div class="post-footer">
                        <a class="more-link" href="">Продолжить чтение</a>
                        <div class="post-social">
                            <a href="" target="_blank"><i class="fa fa-facebook"></i></a>
                            <a href="" target="_blank"><i class="fa fa-twitter"></i></a>
                            <a href="" target="_blank"><i class="fa fa-pinterest"></i></a>
                        </div>
                    </div>
                </div>
            </article>
            <article id="post-2" class="post">
                ...
            </article>
        </div> <!-- конец div class="posts-list"-->
    </div>
    <footer>
        <div class="container">
            <div class="footer-col"><span>www.biletsconcert.ru</span></div>
            <div class="footer-col">
                <div class="social-bar-wrap">
                    <a title="Facebook" href="" target="_blank"><i class="fa fa-facebook"></i></a>
                    <a title="Twitter" href="" target="_blank"><i class="fa fa-twitter"></i></a>
                    <a title="Pinterest" href="" target="_blank"><i class="fa fa-pinterest"></i></a>
                    <a title="Instagram" href="" target="_blank"><i class="fa fa-instagram"></i></a>
                </div>
            </div>
            <div class="footer-col">
                <a href="mailto:admin@yoursite.ru">концерты.ру</a>
            </div>
        </div>
    </footer>

</body>

</html>