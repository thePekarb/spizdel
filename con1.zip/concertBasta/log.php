<?php

$conn = mysqli_connect("localhost", "root", "root", "concert");
if (!$conn) {
    die("Ошибка: " . mysqli_connect_error());
}

?>
<!DOCTYPE HTML>
<html>
 <head>
  <meta charset="utf-8">
  <title>Авторизация</title>
  <link rel="stylesheet" href="css/style.css">
 </head>
 <body>
 <form action="check.php" class='form' method="POST">
<p>Логин</p>
<input class="input" name="login" type="text" required>
<p>Пароль</p>  
<input class="input" name="password" type="password" required>
<input class="but" name="submit" type="submit" value="Войти">
<p class="text_reg"><a href="reg.php" id='reg_text'>Регистрация</a></p>
<p class="text_reg"><a href="index.php" id='reg_text'>Назад</a></p>

</form>   
 </body>
