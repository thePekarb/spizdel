<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Адаптивная вёрстка сайта</title>
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Open+Sans:400,400italic,600,600italic,700,700italic|Playfair+Display:400,700&subset=latin,cyrillic">
    <link rel="stylesheet" type="text/css" href="style2.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.2/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/prefixfree/1.0.7/prefixfree.min.js"></script>
</head>

<body>
    <header>
        <nav class="container nav__container">
            <a class="logo" href="">
                <p>Купить билеты.ру</p>
            </a>
            <!-- <div class="nav-toggle"><span></span></div> -->
            <form action="" method="get" id="searchform">
                <input type="text" placeholder="Искать на сайте...">
                <button type="submit"><i class="fa fa-search"></i></button>
            </form>
            <ul class="menu">
                <li><a href="index2.php">Меню</a></li>
                <li><a href="">Контакты</a></li>
                <li><a href="">Об авторе</a></li>
            </ul>
        </nav>
    </header>
    <div class="container">
        <center><div class="posts-list">
            <article id="post-1" class="post">
                <div class="post-image"><a href="">
                
                
                    </a></div>
              <div class="post-content">
                    <div class="category"><a href="index2.php">Вернуться назад</a></div>
                    <h2 class="post-title">Дата проведения концерта</h2>
                    <div class="calendar-item">
			<div class="calendar-head">Октябрь 2022</div>
			<table>
				<tr>
					<th>Пн</th>
					<th>Вт</th>
					<th>Ср</th>
					<th>Чт</th>
					<th>Пт</th>
					<th>Сб</th>
					<th>Вс</th>
				</tr><tr><td></td><td></td><td></td><td></td><td></td><td class="calendar-day last">1</td><td class="calendar-day last">2</td></tr><tr><td class="calendar-day last">3</td><td class="calendar-day today">4</td><td class="calendar-day ">5</td><td class="calendar-day ">6</td><td class="calendar-day ">7</td><td class="calendar-day ">8</td><td class="calendar-day ">9</td></tr><tr><td class="calendar-day ">10</td><td class="calendar-day ">11</td><td class="calendar-day ">12</td><td class="calendar-day ">13</td><td class="calendar-day ">14</td><td class="calendar-day ">15</td><td class="calendar-day ">16</td></tr><tr><td class="calendar-day ">17</td><td class="calendar-day ">18</td><td class="calendar-day ">19</td><td class="calendar-day ">20</td><td class="calendar-day ">21</td><td class="calendar-day ">22</td><td class="calendar-day ">23</td></tr><tr><td class="calendar-day ">24</td><td class="calendar-day ">25</td><td class="calendar-day ">26</td><td class="calendar-day ">27</td><td class="calendar-day ">28</td><td class="calendar-day ">29</td><td class="calendar-day ">30</td></tr><tr><td class="calendar-days "><a href="#432451"></a>31</td></tr></table></div>
				<a class="more-links"><h1>Концерт в 19:00</h1></a>
<style type="text/css">
.calendar-item {
	width: 350px;
    height: 200px;
	display: inline-block;
	vertical-align: top;
	margin: 0 16px 20px;
	font: 14px/1.2 Arial, sans-serif;
}
.calendar-head {
	text-align: center;
	padding: 5px;
	font-weight: 700;
	font-size: 14px;
}
    .calendar-days{
        background-color: yellow;
    }
.calendar-item table {
	border-collapse: collapse;
	width: 100%;
}
.calendar-item th {
	font-size: 12px;
	padding: 6px 7px;
	text-align: center;
	color: #888;
	font-weight: normal;
}
.calendar-item td {
	font-size: 13px;
	padding: 6px 5px;
	text-align: center;
	border: 1px solid #ddd;
}
.calendar-item tr th:nth-child(6), .calendar-item tr th:nth-child(7),
.calendar-item tr td:nth-child(6), .calendar-item tr td:nth-child(7)  {
	color: #e65a5a;
}	
.calendar-day.last {
	color: #999 !important;
}	
.calendar-day.today {
	font-weight: bold;
}
.calendar-day.event {
	background: #ffe2ad;
	position: relative;
	cursor: pointer;
}
.calendar-day.event:hover .calendar-popup {
	display: block;
}
.calendar-popup {
	display: none;
	position: absolute;
	top: 40px;
	left: 0;
	min-width: 200px;
	padding: 15px;
	background: #fff;
	text-align: left;
	font-size: 13px;
	z-index: 100;
	box-shadow: 0 0 10px rgba(0,0,0,0.5);
	color: #000;
}
.calendar-popup:before {
	content: ""; 
	border: solid transparent;
	position: absolute;    
	left: 8px;    
	bottom: 100%;
	border-bottom-color: #fff;
	border-width: 9px;
	margin-left: 0;
}
</style>

                    <div class="post-footer">
                       
                        <a class="more-link" href="parter.php">Продолжить </a>
                        <div class="post-social">
                            <a href="" target="_blank"><i class="fa fa-facebook"></i></a>
                            <a href="" target="_blank"><i class="fa fa-twitter"></i></a>
                            <a href="" target="_blank"><i class="fa fa-pinterest"></i></a>
                        </div>
                    </div>
                </div>
            </article>
            <article id="post-2" class="post">
                ...
            </article>
        </div></center> <!-- конец div class="posts-list"-->
    </div>
    <footer>
        <div class="container">
            <div class="footer-col"><span>www.biletsconcert.ru</span></div>
            <div class="footer-col">
                <div class="social-bar-wrap">
                    <a title="Facebook" href="" target="_blank"><i class="fa fa-facebook"></i></a>
                    <a title="Twitter" href="" target="_blank"><i class="fa fa-twitter"></i></a>
                    <a title="Pinterest" href="" target="_blank"><i class="fa fa-pinterest"></i></a>
                    <a title="Instagram" href="" target="_blank"><i class="fa fa-instagram"></i></a>
                </div>
            </div>
            <div class="footer-col">
                <a href="mailto:admin@yoursite.ru">концерты.ру</a>
            </div>
        </div>
    </footer>

</body>

</html>